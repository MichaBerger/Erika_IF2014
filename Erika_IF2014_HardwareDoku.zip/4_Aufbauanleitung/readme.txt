Juni 2025: Aufbauanleitung wird demnächst erstellt - sobald neue 
Platinencharge von JLCPCB verfügbar ist.